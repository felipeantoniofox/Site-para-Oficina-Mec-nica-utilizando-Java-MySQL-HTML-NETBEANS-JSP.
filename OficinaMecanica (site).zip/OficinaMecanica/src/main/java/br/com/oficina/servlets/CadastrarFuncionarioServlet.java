package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(name = "CadastrarFuncionarioServlet", urlPatterns = {"/cadastrarFuncionario"})
public class CadastrarFuncionarioServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String nome = req.getParameter("nome");
        String funcao = req.getParameter("funcao");
        String dataAdmissaoStr = req.getParameter("data_admissao");
        String salarioStr = req.getParameter("salario");
        BigDecimal salario = new BigDecimal(salarioStr);
        int cargaHorariaSemanal = Integer.parseInt(req.getParameter("cargaHorariaSemanal"));
        String beneficios = req.getParameter("beneficios");

        // Converter a data tentando os dois formatos: dd/MM/yyyy e yyyy-MM-dd
        java.sql.Date dataAdmissao = null;
        try {
            dataAdmissao = parseDate(dataAdmissaoStr);
        } catch (ParseException e) {
            throw new ServletException("Formato da data inválido. Use dd/MM/yyyy ou yyyy-MM-dd.", e);
        }

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            // Inserir o novo funcionário no banco de dados
            String sql = "INSERT INTO funcionarios (nome, funcao, data_admissao, salario, carga_horaria_semanal, beneficios) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, funcao);
            stmt.setDate(3, dataAdmissao);
            stmt.setBigDecimal(4, salario);
            stmt.setInt(5, cargaHorariaSemanal);
            stmt.setString(6, beneficios);
            stmt.executeUpdate();

            // Calcular o total de funcionários e o total de salários
            String countSql = "SELECT COUNT(*) AS totalFuncionarios, SUM(salario) AS totalSalario FROM funcionarios";
            PreparedStatement countStmt = con.prepareStatement(countSql);
            ResultSet countRs = countStmt.executeQuery();
            if (countRs.next()) {
                int totalFuncionarios = countRs.getInt("totalFuncionarios");
                BigDecimal totalSalario = countRs.getBigDecimal("totalSalario");

                // Enviar os dados para o JSP
                req.setAttribute("totalFuncionarios", totalFuncionarios);
                req.setAttribute("totalSalario", totalSalario);
            }

            // Redirecionar para a página de funcionários
            res.sendRedirect("funcionarios.jsp");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    // Método auxiliar que tenta converter a data usando dois formatos diferentes
    private java.sql.Date parseDate(String dateStr) throws ParseException {
        // Primeiro tenta dd/MM/yyyy
        SimpleDateFormat sdfBr = new SimpleDateFormat("dd/MM/yyyy");
        sdfBr.setLenient(false);
        try {
            java.util.Date parsed = sdfBr.parse(dateStr);
            return new java.sql.Date(parsed.getTime());
        } catch (ParseException e) {
            // Se falhar, tenta yyyy-MM-dd
            SimpleDateFormat sdfIso = new SimpleDateFormat("yyyy-MM-dd");
            sdfIso.setLenient(false);
            java.util.Date parsed = sdfIso.parse(dateStr);
            return new java.sql.Date(parsed.getTime());
        }
    }
}
