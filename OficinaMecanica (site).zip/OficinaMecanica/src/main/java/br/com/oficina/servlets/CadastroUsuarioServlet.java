package br.com.oficina.servlets;

import com.mycompany.oficinamecanica.Conexao;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;  // IMPORTANTE!
import java.io.IOException;
import java.sql.*;

@WebServlet(name = "CadastroUsuarioServlet", urlPatterns = {"/cadastrarUsuario"})
public class CadastroUsuarioServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String usuario = req.getParameter("usuario");
        String senha   = req.getParameter("senha");

        // Exemplo simples de validação: nenhum campo pode ser vazio
        if (usuario == null || usuario.trim().isEmpty() ||
            senha   == null || senha.trim().isEmpty()) {
            req.setAttribute("erro", "Usuário e senha são obrigatórios.");
            req.getRequestDispatcher("cadastroUsuario.jsp").forward(req, res);
            return;
        }

        try (Connection con = Conexao.getConnection()) {
            String sql = "INSERT INTO usuarios (usuario, senha) VALUES (?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);
            stmt.executeUpdate();

            // Se cadastrou com sucesso, redirecionar para o login
            res.sendRedirect("login.jsp");
        } catch (SQLException e) {
            // Em caso de erro (por exemplo, chave única violada), mostra mensagem na página
            req.setAttribute("erro", "Erro ao cadastrar usuário. Verifique se já existe.");
            req.getRequestDispatcher("cadastroUsuario.jsp").forward(req, res);
        }
    }
}
