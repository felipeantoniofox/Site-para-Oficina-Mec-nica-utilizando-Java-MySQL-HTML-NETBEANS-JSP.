package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(name = "EditarFuncionarioServlet", urlPatterns = {"/editarFuncionario"})
public class EditarFuncionarioServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String nome = req.getParameter("nome");
        String funcao = req.getParameter("funcao");
        String dataAdmissaoStr = req.getParameter("data_admissao");
        String salarioStr = req.getParameter("salario");
        BigDecimal salario = new BigDecimal(salarioStr);
        int cargaHorariaSemanal = Integer.parseInt(req.getParameter("cargaHorariaSemanal"));
        String beneficios = req.getParameter("beneficios");

        // Converter data aceitando dd/MM/yyyy ou yyyy-MM-dd
        java.sql.Date dataAdmissao = null;
        try {
            if (dataAdmissaoStr.contains("/")) {
                // Formato esperado: dd/MM/yyyy
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                java.util.Date parsed = format.parse(dataAdmissaoStr);
                dataAdmissao = new java.sql.Date(parsed.getTime());
            } else {
                // Formato esperado: yyyy-MM-dd
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date parsed = format.parse(dataAdmissaoStr);
                dataAdmissao = new java.sql.Date(parsed.getTime());
            }
        } catch (ParseException e) {
            throw new ServletException("Formato da data inválido. Use dd/MM/yyyy ou yyyy-MM-dd.", e);
        }

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "UPDATE funcionarios SET nome = ?, funcao = ?, data_admissao = ?, salario = ?, carga_horaria_semanal = ?, beneficios = ? WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, funcao);
            stmt.setDate(3, dataAdmissao);
            stmt.setBigDecimal(4, salario);
            stmt.setInt(5, cargaHorariaSemanal);
            stmt.setString(6, beneficios);
            stmt.setInt(7, id);
            stmt.executeUpdate();

            res.sendRedirect("funcionarios.jsp");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
