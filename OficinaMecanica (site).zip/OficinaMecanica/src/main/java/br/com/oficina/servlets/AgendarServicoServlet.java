package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

@WebServlet(name = "AgendarServicoServlet", urlPatterns = {"/agendarServico"})
public class AgendarServicoServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String nome = req.getParameter("cliente_nome");
        String email = req.getParameter("cliente_email");
        String veiculo = req.getParameter("veiculo");
        String servico = req.getParameter("servico");
        String data = req.getParameter("data_agendada");
        String horario = req.getParameter("horario_agendado");

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "INSERT INTO agendamentos (cliente_nome, cliente_email, veiculo, servico, data_agendada, horario_agendado) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, email);
            stmt.setString(3, veiculo);
            stmt.setString(4, servico);
            stmt.setDate(5, Date.valueOf(data));
            stmt.setString(6, horario);
            stmt.executeUpdate();

            // Redirecionar para uma página simples de confirmação
            res.sendRedirect("confirmacaoAgendamento.jsp");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
