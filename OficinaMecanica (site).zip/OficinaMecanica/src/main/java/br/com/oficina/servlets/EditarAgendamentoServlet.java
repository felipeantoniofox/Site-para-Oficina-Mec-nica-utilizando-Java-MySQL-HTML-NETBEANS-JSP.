package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(name = "EditarAgendamentoServlet", urlPatterns = {"/editarAgendamento"})
public class EditarAgendamentoServlet extends HttpServlet {

    // Método GET: buscar dados do agendamento pelo ID e enviar para o JSP preencher o formulário
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "SELECT * FROM agendamentos WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                req.setAttribute("id", rs.getInt("id"));
                req.setAttribute("clienteNome", rs.getString("cliente_nome"));
                req.setAttribute("clienteEmail", rs.getString("cliente_email"));
                req.setAttribute("veiculo", rs.getString("veiculo"));
                req.setAttribute("servico", rs.getString("servico"));
                req.setAttribute("dataAgendada", rs.getDate("data_agendada").toString());
                req.setAttribute("horarioAgendado", rs.getString("horario_agendado"));
            } else {
                // Caso não encontre o agendamento, redireciona ou mostra mensagem
                res.sendRedirect("listarAgendamentos");
                return;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        // Encaminha para o JSP que mostra o formulário preenchido para edição
        req.getRequestDispatcher("editarAgendamento.jsp").forward(req, res);
    }

    // Método POST: recebe os dados do formulário para atualizar o agendamento
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String clienteNome = req.getParameter("clienteNome");
        String clienteEmail = req.getParameter("clienteEmail");
        String veiculo = req.getParameter("veiculo");
        String servico = req.getParameter("servico");
        String dataAgendadaStr = req.getParameter("dataAgendada");
        String horarioAgendado = req.getParameter("horarioAgendado");

        java.sql.Date dataAgendada = null;
        try {
            dataAgendada = parseDate(dataAgendadaStr);
        } catch (ParseException e) {
            throw new ServletException("Formato da data inválido. Use yyyy-MM-dd.", e);
        }

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "UPDATE agendamentos SET cliente_nome = ?, cliente_email = ?, veiculo = ?, servico = ?, data_agendada = ?, horario_agendado = ? WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, clienteNome);
            stmt.setString(2, clienteEmail);
            stmt.setString(3, veiculo);
            stmt.setString(4, servico);
            stmt.setDate(5, dataAgendada);
            stmt.setString(6, horarioAgendado);
            stmt.setInt(7, id);

            stmt.executeUpdate();

            res.sendRedirect("listarAgendamentos");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private java.sql.Date parseDate(String dateStr) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        java.util.Date parsed = sdf.parse(dateStr);
        return new java.sql.Date(parsed.getTime());
    }
}
