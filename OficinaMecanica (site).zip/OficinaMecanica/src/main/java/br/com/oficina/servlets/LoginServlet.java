package br.com.oficina.servlets;

import com.mycompany.oficinamecanica.Conexao;  // Importa a classe Conexao correta
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String usuario = req.getParameter("usuario");
        String senha = req.getParameter("senha");

        try (Connection con = Conexao.getConnection()) {
            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);  // Atenção: em produção, use hash para senha!
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("usuarioLogado", usuario);
                res.sendRedirect("dashboard.jsp");
            } else {
                req.setAttribute("erro", "Usuário ou senha inválidos");
                req.getRequestDispatcher("login.jsp").forward(req, res);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        // Redireciona GET para página de login ou trate como preferir
        req.getRequestDispatcher("login.jsp").forward(req, res);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para autenticação de usuários";
    }
}
