package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ListarAgendamentosServlet", urlPatterns = {"/listarAgendamentos"})
public class ListarAgendamentosServlet extends HttpServlet {

    public static class Agendamento {
        private int id;
        private String clienteNome;
        private String clienteEmail;
        private String veiculo;
        private String servico;
        private Date dataAgendada;
        private String horarioAgendado;

        // Construtor, getters e setters
        public Agendamento(int id, String clienteNome, String clienteEmail, String veiculo,
                           String servico, Date dataAgendada, String horarioAgendado) {
            this.id = id;
            this.clienteNome = clienteNome;
            this.clienteEmail = clienteEmail;
            this.veiculo = veiculo;
            this.servico = servico;
            this.dataAgendada = dataAgendada;
            this.horarioAgendado = horarioAgendado;
        }
        public int getId() { return id; }
        public String getClienteNome() { return clienteNome; }
        public String getClienteEmail() { return clienteEmail; }
        public String getVeiculo() { return veiculo; }
        public String getServico() { return servico; }
        public Date getDataAgendada() { return dataAgendada; }
        public String getHorarioAgendado() { return horarioAgendado; }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Agendamento> agendamentos = new ArrayList<>();

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "SELECT * FROM agendamentos ORDER BY data_agendada, horario_agendado";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Agendamento ag = new Agendamento(
                    rs.getInt("id"),
                    rs.getString("cliente_nome"),
                    rs.getString("cliente_email"),
                    rs.getString("veiculo"),
                    rs.getString("servico"),
                    rs.getDate("data_agendada"),
                    rs.getString("horario_agendado")
                );
                agendamentos.add(ag);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        req.setAttribute("agendamentos", agendamentos);
        req.getRequestDispatcher("listaAgendamento.jsp").forward(req, res);
    }
}
