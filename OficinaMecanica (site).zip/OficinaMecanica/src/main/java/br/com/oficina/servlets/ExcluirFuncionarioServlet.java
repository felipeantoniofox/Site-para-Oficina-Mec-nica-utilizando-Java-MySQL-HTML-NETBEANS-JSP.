package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;  // IMPORTANTE!
import java.io.IOException;
import java.sql.*;

@WebServlet(name = "ExcluirFuncionarioServlet", urlPatterns = {"/excluirFuncionario"})
public class ExcluirFuncionarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "DELETE FROM funcionarios WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            res.sendRedirect("funcionarios.jsp");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
