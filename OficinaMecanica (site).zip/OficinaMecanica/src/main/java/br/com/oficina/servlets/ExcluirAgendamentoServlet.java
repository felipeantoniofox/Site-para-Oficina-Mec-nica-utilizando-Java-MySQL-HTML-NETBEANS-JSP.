package br.com.oficina.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

@WebServlet(name = "ExcluirAgendamentoServlet", urlPatterns = {"/excluirAgendamento"})
public class ExcluirAgendamentoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String idParam = req.getParameter("id");
        if (idParam == null || idParam.isEmpty()) {
            res.sendRedirect("listarAgendamentos");
            return;
        }

        int id = Integer.parseInt(idParam);

        try (Connection con = com.mycompany.oficinamecanica.Conexao.getConnection()) {
            String sql = "DELETE FROM agendamentos WHERE id = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            res.sendRedirect("listarAgendamentos");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
