/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.oficinamecanica;

/**
 *
 * @author Felipe
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
     private static final String URL = "jdbc:mysql://localhost:3306/oficina"; // endereço do banco
    private static final String USER = "root"; // usuário do banco 
    private static final String PASSWORD = "Feliperx580@"; // sua senha do banco
    
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // carrega o driver MySQL
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
